# Ethereum Prototype
This project is prototype of Ethereum Blockchain Platform built from scratch in Node.js